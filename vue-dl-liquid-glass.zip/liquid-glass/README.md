# vue-dl · liquid glass engine

One physics model — SDF → surface normals → **Snell's-law refraction** → displacement field — with two backends:

| Layer | What it is | Runs on |
|---|---|---|
| `core/` | Pure TypeScript. Zero deps, zero DOM, zero RN. The equations. | everywhere |
| `web/` | Vue 3 composable + `VdGlass`. Rasterizes the field on the CPU into an SVG `feDisplacementMap` applied via `backdrop-filter: url(#…)`. | browsers |
| `native/` | Expo/RN view. iOS 26 gets the real `UIGlassEffect`; everything else runs `core/sksl.ts` — the same math transliterated to SKSL — on the GPU via `@shopify/react-native-skia`. | iOS + Android |

The web rasterizer (`core/rasterize.ts`) and the GPU shader (`core/sksl.ts`) are
line-for-line the same functions (`sdRoundedBox`, `bezelProfile`,
`surfaceNormal`, `refractDisplacement`, `specularIntensity`). Tune a constant in
one, mirror it in the other.

## How the light bending works

1. **SDF.** Signed distance to the rounded-rect edge gives both *how far into
   the rim* a pixel is and (via the gradient) *which way the edge faces*.
2. **Surface.** A flat slab of thickness `depth` with a quarter-circle "lens"
   bezel of width `bezelWidth` around the rim. Height field
   `H = depth · h(clamp(-sdf/bezel))`, normal `n = normalize(-∇H, 1)`.
3. **Refraction.** A view ray `(0,0,-1)` refracts at the surface with
   `η = 1/ior` (Snell), travels down through the slab, and lands on the
   backdrop offset by `T.xy · depth / -T.z`. That offset is the displacement.
   On the flat plateau `n = +z`, so displacement is exactly zero — the middle
   of the glass stays perfectly readable, only the rim lenses. That's the
   signature iOS 26 behavior, and it falls out of the physics for free.
4. **Specular.** Blinn–Phong rim highlight from an upper-left key light,
   suppressed on the plateau.

## Web — drop into `packages/vue-dl`

```
src/engine/liquid-glass/      ← core/* (rename core → this)
src/composables/liquidGlass.ts← web/useLiquidGlass.ts
src/components/VdGlass/       ← web/VdGlass.tsx + VdGlass.scss + index.ts
```

```vue
<VdGlass :radius="28" :depth="16" :ior="1.45" interactive>
  <nav class="toolbar">…</nav>
</VdGlass>
```

Or raw, on any element:

```ts
const el = ref<HTMLElement | null>(null)
const { glassStyle, highlightStyle, refracting } = useLiquidGlass(el, {
  bezelWidth: 22, depth: 16, ior: 1.45, profile: 'lens',
})
```

Maps regenerate only on resize / option change (ResizeObserver + rAF). While
dragging or scrolling, `backdrop-filter` resamples the live backdrop with the
*existing* map — zero per-frame JS cost.

**Browser truth table (June 2026):** Chromium applies SVG filters inside
`backdrop-filter` → full refraction. Safari and Firefox don't, so
`useLiquidGlass` detects this and serves `blur + saturate` plus the rim
highlight + bevel shadows — a convincing frosted approximation, never a broken
filter. `prefers-reduced-transparency` collapses to an opaque surface.

## Expo — iOS + Android

```bash
npx expo install expo-glass-effect @shopify/react-native-skia
```

```tsx
import { LiquidGlassView } from './native/LiquidGlassView'

// iOS 26+: real system Liquid Glass (live backdrop, free).
// Android / older iOS: GLASS_SKSL on the GPU.
<LiquidGlassView radius={28} options={{ depth: 16, chromaticAberration: 0.4 }}>
  <Text>Toolbar</Text>
</LiquidGlassView>
```

**The Android constraint, honestly:** Android has no system API that lets an
app sample pixels behind an arbitrary native view — even `expo-blur`
approximates there. The Skia path therefore refracts what's behind the filter
*inside a Skia canvas*. Two patterns:

1. **Backdrop-in-canvas** (best, fully live): render the background — image,
   gradient, video frame, chart — inside the same `<Canvas>`; the
   `BackdropFilter` bends it in real time per frame on the GPU.
2. **Snapshot** (`useBackdropSnapshot`): screenshot the native view behind the
   glass with `makeImageFromView`, pass it as `backdrop`. Re-`capture()` when
   the background changes. Right for mostly-static screens.

The GPU path also does **chromatic aberration** (per-channel IOR split at the
rim) — set `chromaticAberration: 0…1`.

## Options (shared across platforms)

| option | default | meaning |
|---|---|---|
| `bezelWidth` | 18 | width (px) of the light-bending rim |
| `depth` | 14 | slab thickness px — scales bend strength |
| `ior` | 1.45 | index of refraction (glass ≈ 1.45–1.52) |
| `profile` | `'lens'` | `'lens'` (iOS look) or `'smooth'` |
| `chromaticAberration` | 0.35 | RGB split at the rim (GPU path only) |
| `specular` | upper-left | `{ intensity, shininess, lightDir }` |
| `blur` / `saturation` / `tint` | 2 / 1.6 / white 10% | cosmetic layers |

## Verified in this build

- Core math: plateau displacement exactly `(0,0)`; rim refraction direction
  matches convex-lens optics; encode/decode round-trips through the 8-bit map.
- `GLASS_SKSL` compiles in real Skia (CanvasKit), 9 uniforms bound.
- Type-checks under strict TS 5.x.
- `liquid-glass-demo.html` — drag-the-lens demo over a test chart with live
  IOR / depth / bezel / radius sliders (full refraction in Chrome/Edge).
